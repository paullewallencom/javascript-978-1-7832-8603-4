#! /bin/bash

sudo apt-get install -y tasksel
sudo tasksel install lamp-server

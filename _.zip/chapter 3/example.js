
var x = "This is the value of variable x and is being retrieved from an external javascript file";
